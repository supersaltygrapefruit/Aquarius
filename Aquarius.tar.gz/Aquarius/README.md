# GrassfedCow
Gnome and Cinnamon themes
mod of Graphite  https://github.com/vinceliuice/Graphite-gtk-theme
